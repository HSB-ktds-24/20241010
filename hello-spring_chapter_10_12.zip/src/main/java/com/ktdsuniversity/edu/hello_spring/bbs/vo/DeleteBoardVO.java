package com.ktdsuniversity.edu.hello_spring.bbs.vo;

public class DeleteBoardVO {

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private int id;
	private String email;
}
