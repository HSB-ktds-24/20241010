package com.ktdsuniversity.edu.do_to_list.bbs.vo;

public class UpdateVO {

}
