package com.ktdsuniversity.edu.do_to_list.bbs.vo;

import jakarta.validation.constraints.NotEmpty;

public class ScheduleWriteVO {

	@NotEmpty(message = "내용을 입력해주세요.")
	private String subject;	
	@NotEmpty(message = "날자을 입력해주세요.")
	private String deadline;
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDeadline() {
		return deadline;
	}
	public void setDeadline(String deadline) {
		this.deadline = deadline;
	}

	
}
