package com.ktdsuniversity.edu.do_to_list.member.dao.impl;


import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ktdsuniversity.edu.do_to_list.member.dao.MemberDao;
import com.ktdsuniversity.edu.do_to_list.member.vo.MemberWriteVO;

@Repository
public class MemberDaoImpl extends SqlSessionDaoSupport implements MemberDao{
	@Autowired
	@Override
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		super.setSqlSessionTemplate(sqlSessionTemplate);
	}
	@Override
	public int insertNewMember(MemberWriteVO memberWriteVO) {
		return getSqlSession().insert(NAMESPACE+".insertNewMember", memberWriteVO);
	}
	@Override
	public int selectEmailCount(String email) {
		
		return getSqlSession().selectOne(NAMESPACE+".selectEmailCount" ,email);
	}

}
