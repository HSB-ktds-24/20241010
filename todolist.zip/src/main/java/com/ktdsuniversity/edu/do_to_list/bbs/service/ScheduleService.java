package com.ktdsuniversity.edu.do_to_list.bbs.service;

import java.util.List;

import com.ktdsuniversity.edu.do_to_list.bbs.vo.DeleteVO;
import com.ktdsuniversity.edu.do_to_list.bbs.vo.ScheduleVO;
import com.ktdsuniversity.edu.do_to_list.bbs.vo.ScheduleWriteVO;
import com.ktdsuniversity.edu.do_to_list.bbs.vo.UpdateVO;

public interface ScheduleService {

	public boolean createSchedule(ScheduleWriteVO scheduleWriteVO);
	public boolean removeSchedule(DeleteVO deleteVO);
	public boolean updateState(UpdateVO updateVO);
	public List<ScheduleVO> showAllSchedule();
	
	
}
