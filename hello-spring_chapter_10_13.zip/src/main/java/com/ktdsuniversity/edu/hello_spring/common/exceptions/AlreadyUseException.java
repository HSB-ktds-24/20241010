package com.ktdsuniversity.edu.hello_spring.common.exceptions;


import com.ktdsuniversity.edu.hello_spring.member.vo.MemberWriteVO;

public class AlreadyUseException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6172744969616117842L;
	
	private MemberWriteVO memberWriteVO;
	
	public AlreadyUseException(MemberWriteVO memberWriteVO, String message) {
		super(message);
		this.memberWriteVO = memberWriteVO;
	}

	public MemberWriteVO getMemberWriteVO(){
		return memberWriteVO;
	}
	

	

}
