package com.ktdsuniversity.edu.hello_spring.common.exceptions;

public class MakeXlsxFileException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2565447014297733161L;

	public MakeXlsxFileException(String message) {
		super(message);
	}

}
