package com.ktdsuniversity.edu.hello_spring.common.exceptions.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ktdsuniversity.edu.hello_spring.common.exceptions.AlreadyUseException;
import com.ktdsuniversity.edu.hello_spring.common.exceptions.FileNotExistsException;
import com.ktdsuniversity.edu.hello_spring.common.exceptions.MakeXlsxFileException;
import com.ktdsuniversity.edu.hello_spring.common.exceptions.PageNotFoundException;
import com.ktdsuniversity.edu.hello_spring.common.exceptions.UserIdendifyNotMatchException;

@ControllerAdvice// 예외를 일괄 처리함 컨트롤러와 성격이 같음
public class GlobalExceptionHanlder {

	public static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHanlder.class);
	
	@ExceptionHandler(PageNotFoundException.class)
	public String viewPageNotFoundPage() {
		
		if(logger.isDebugEnabled()) {
			logger.debug("페이지를 찾을 수 없습니다");
		}
		
		return "error/404";
	}
	
	 @ExceptionHandler({FileNotExistsException.class, MakeXlsxFileException.class})
	 public String viewFileExceoption(Model model , RuntimeException e) {
		
		if(e instanceof FileNotExistsException) {
			FileNotExistsException fnee = (FileNotExistsException) e;
			model.addAttribute("message", fnee.getMessage());
		}
		else if(e instanceof MakeXlsxFileException) {
			MakeXlsxFileException mxfe = (MakeXlsxFileException) e;
			model.addAttribute("message", mxfe.getMessage());
		}
		
		 return "error/500";
	 }
	
	
	@ExceptionHandler(UserIdendifyNotMatchException.class)
	public String viewLoginErrorPage(Model model, 
									UserIdendifyNotMatchException uinme) {
		
		if(logger.isDebugEnabled()) {
			logger.debug("아이디가 일치하지 않습니다");
		}
		
		model.addAttribute("message",uinme.getMessage());
		model.addAttribute("loginMemberVO",uinme.getLoginMemberVO());
		return "member/memberlogin";
	}
	
	@ExceptionHandler(AlreadyUseException.class)
	public String viewAlreadyUsePage(Model model, AlreadyUseException aue ) {
		
		model.addAttribute("message",aue.getMessage());
		model.addAttribute("memberWriteVO",aue.getMemberWriteVO());
		return "member/memebrregist";
	}
	

}
