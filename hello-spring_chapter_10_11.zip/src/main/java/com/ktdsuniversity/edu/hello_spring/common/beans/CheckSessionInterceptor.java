package com.ktdsuniversity.edu.hello_spring.common.beans;

import org.springframework.web.servlet.HandlerInterceptor;

import com.ktdsuniversity.edu.hello_spring.member.vo.MemberVO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class CheckSessionInterceptor implements HandlerInterceptor{

	@Override
	public boolean preHandle( HttpServletRequest request
							, HttpServletResponse response
							, Object handler)
			 throws Exception {
		//1.세션 가져오기
		HttpSession session = request.getSession();
		//2. 유무 판단
		MemberVO memberVO = (MemberVO) session.getAttribute("_LOGIN_USER_");
		
		if(memberVO !=null) {
			return true; // 칸트롤러 실행
		}
		
		//3.로그인 페이지 보여주기
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/views/member/memberlogin.jsp");
		rd.forward(request, response);
		
		return false; //컨트롤러 미실행
	}
	
	/*
	@Override
	public void postHandle( HttpServletRequest request
						  , HttpServletResponse response
						  , Object handler
						  , ModelAndView modelAndView) throws Exception {
			System.out.println("CheckSessionInterceptor.postHandle"+handler);
			System.out.println("CheckSessionInterceptor.postHandle"+modelAndView);
	}
	
	@Override
	public void afterCompletion( HttpServletRequest request
							   , HttpServletResponse response
							   , Object handler
							   , Exception ex) throws Exception {
			System.out.println("CheckSessionInterceptor.afterCompletion"+handler);
	}
	
	*/
}
