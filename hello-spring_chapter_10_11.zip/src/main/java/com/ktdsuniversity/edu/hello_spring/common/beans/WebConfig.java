package com.ktdsuniversity.edu.hello_spring.common.beans;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ktdsuniversity.edu.hello_spring.access.dao.AccessLogDao;

//스프링 빈을 수동으로 생성하는 기능
@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer{

	@Autowired
	private AccessLogDao accessLogDao;
	
	@Value("${app.interceptors.check-session.path-patterns}")
	private List<String> checkSessionPathPatterns;
	@Value("${app.interceptors.check-session.exclude-path-patterns}")
	private List<String> checkSessionExcludePathPatterns;
	
	@Value("${app.interceptors.check-dup-login.path-patterns}")
	private List<String> checkDupLoginPathPatterns;
	@Value("${app.interceptors.check-dup-login.exclude-path-patterns}")
	private List<String> checkDupLoginExcludePathPatterns;
	
	@Value("${app.interceptors.add-access-log.path-patterns}")
	private List<String> addAccessLogPathPatterns;
	@Value("${app.interceptors.add-access-log.exclude-path-patterns}")
	private List<String> addAccessLoginExcludePathPatterns;
	
	// 오토 > @coStringt 
	// tnehd >@bean
	@Bean
	 Sha createShaInstance() {
		Sha sha = new Sha();
		return sha;
	}
	
	// jsp view resolver
	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
		registry.jsp("/WEB-INF/views/",".jsp");
	}
	
	// static resource 설정
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/css/**").addResourceLocations("classpath:/static/css/");
		registry.addResourceHandler("/js/**").addResourceLocations("classpath:/static/js/");
	}
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		
	
		registry.addInterceptor(new CheckSessionInterceptor())
				.addPathPatterns(this.checkSessionExcludePathPatterns)
				.excludePathPatterns(this.checkSessionExcludePathPatterns);
	
		registry.addInterceptor(new CheckDuplicateLoginInterceptor())
				.addPathPatterns(this.checkDupLoginPathPatterns)
				.excludePathPatterns(this.checkDupLoginExcludePathPatterns);
	
		registry.addInterceptor(new AddAccessLogHistoryInterceptor(this.accessLogDao))
				.addPathPatterns(this.addAccessLogPathPatterns)
				.excludePathPatterns(this.addAccessLoginExcludePathPatterns);
							}
}
