$().ready(function () {
  var pathname = location.pathname;
  var searh = location.search;

  var nextUrl = "";
  if (pathname === "/member/login") {
    nextUrl = "/board/list";
  } else {
    nextUrl = pathname + searh;
  }

  $("input[name = nextUrl]").val(nextUrl);
});
